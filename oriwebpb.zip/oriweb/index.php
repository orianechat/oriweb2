<?php
$dateDebutSoldes = "2026-07-01";
$dateFinSoldes = "2026-07-31";
$aujourdhui = date("Y-m-d");

if ($aujourdhui >= $dateDebutSoldes && $aujourdhui <= $dateFinSoldes) {
    $remiseactive = 20;
} else {
    $remiseactive = 0;
}
?>
<!DOCTYPE html>
<html lang="fr">
<?php
include 'includes/header.php'; ?>

<header>
    <h1>Bienvenue!</h1>
    <p>Ici vous trouverez un incroyable choix d'éléctroménager au meilleur prix.</p>
</header>
<main>
    <section>
        <h2>Top des ventes:</h2>
        <ol>
            <li>Appareils Photos</li>
            <li>Imprimantes</li>
            <li>Ordinateurs</li>
        </ol>
    </section>
    <section>
        <h2>Démo:</h2>
        <video src="./images/istockphoto-1454425463-640_adpp_is.mp4" autoplay muted loop
            width="250" height="200">vidéo de démo</video>
    </section>
</main>
<?php
include 'includes/footer.php'; ?>

</body>


</html>