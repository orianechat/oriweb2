<!DOCTYPE html>
<html lang="fr">

<?php
include 'includes/header.php'; ?>
<main>
    <section>
        <form class="styled-form">
            <div class="form-group">
                <label for="nom">Nom :</label>
                <input type="text" id="nom" name="nom_utilisateur">
            </div>

            <div class="form-group">
                <label for="prénom">Prénom :</label>
                <input type="text" id="Prénom" name="prénom_utilisateur">
            </div>

            <div class="form-group">
                <label for="Genre">Genre:</label>
                <input type="radio" name="Genre" value="H">Homme
                <input type="radio" name="Genre" value="F">Femme
                <input type="radio" name="Genre" value="A">Autre
            </div>

            <div class="form-group">
                <label for="Age">Age :</label>
                <input type="number" id="Age" name="Age" min="0" max="120">
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email_utilisateur">
            </div>

            <div class="form-group">
                <label for="message">Message :</label>
                <textarea id="message" name="message_utilisateur"></textarea>
            </div>
            <div class="form-group">
                <label for="monCheckbox">Conditions générales :</label>
                <input type="checkbox" id="Accepter les conditions générales" name="Accepter les conditions générales" value="oui">
                <a href="https://info.hub.brussels/guide/marketing-vente-e-commerce/les-conditions-generales-de-vente-pourquoi-mais-surtout-comment" class="button-like">Voir les conditions générales</a>
            </div>

            <button type="submit" class="submit-btn">S'inscrire</button>
            <br>

            <a href="/Connection.php" class="button-like">Me connecter</a></button>


        </form>
    </section>
</main>
<?php
include 'includes/footer.php'; ?>