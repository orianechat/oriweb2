<!DOCTYPE html>
<html lang="fr">
<?php
$nom = "Electrogear";
echo $nom;
?>
<?php
include 'includes/head.php'; ?>

<?php
include 'includes/footer.php'; ?>

</body>

</html>