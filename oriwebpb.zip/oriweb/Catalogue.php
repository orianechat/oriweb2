<?php
require_once 'includes/db.php';
include 'includes/header.php';

$sql = "SELECT * FROM produits";
$result = $conn->query($sql);
?>

<main>
    <h1>Notre Catalogue</h1>
    <div class="liste-produits">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="produit">
                    <img src="<?= $row['image'] ?>" alt="<?= $row['nom'] ?>" width="150">
                    <h3><?= $row['nom'] ?></h3>
                    <p><?= $row['prix'] ?> €</p>
                    <a href="produit.php?id=<?= $row['id'] ?>">Voir le détail</a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Aucun produit trouvé.</p>
        <?php endif; ?>
    </div>
</main>

<?php include 'footer.php'; ?>