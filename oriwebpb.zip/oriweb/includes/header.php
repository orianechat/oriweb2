<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connection</title>
    <link rel="shortcut icon" href="images/pngtree-business-logo-design-png-image_915991.jpg">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <nav>
        <div class="logo-container">
            <img src="./images/Logo_entreprise.png" alt="Logo Entreprise" class="logo">
            <span class="company-name">Electrogear</span>
        </div>
        <ul>
            <li><a href="./index.php">Accueil</a></li>
            <li><a href="./Catalogue.php">Catalogue</a></li>
            <li><a href="./Panier.php">Panier</a></li>
            <li><a href="./Contact.php">Contact</a></li>
            <li><a href="./Infos.php">Infos</a></li>
            <li><a href="./Inscription.php">Inscription</a></li>
        </ul>
    </nav>