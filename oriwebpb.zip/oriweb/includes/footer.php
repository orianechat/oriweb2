<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <footer>
        <div class="social-links">
            <a href="https://www.facebook.com/oriane.breuer/" target="_blank" class="app-icon facebook">
                <i class="fab fa-facebook-f"></i>
            </a>
            <a href="https://www.instagram.com/orianebreuer/" target="_blank" class="app-icon instagram">
                <i class="fab fa-instagram"></i>
            </a>
        </div>

        <div class="contact-info">
            <?php
            date_default_timezone_set('Europe/Paris');
            echo "Nous sommes le : " . date('d/m/Y');
            ?>
            <br>
            Mon mail : <a href="mailto:o.breuer@student.helmo.be">o.breuer@student.helmo.be</a>
            <br>
            <strong>&copy; <?php echo date('Y'); ?> - Tous droits réservés</strong>
        </div>
    </footer>