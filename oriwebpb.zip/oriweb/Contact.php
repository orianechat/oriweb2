<!DOCTYPE html>
<html lang="fr">

<?php
include 'includes/header.php'; ?>

<header>
    <h1>Contactez nous ! </h1>
    <p>Notre service client est disponible:
    <ul>
        <li>Lundi de 8h-12h30 et de 13h30-18h. </li>
        <li>Mardi de 8h-12h30 et de 13h30-18h.</li>
        <li>Mercredi de 8h-12h30 et de 13h30-16h.</li>
        <li>Jeudi de 8h-12h30 et de 13h30-18h.</li>
        <li>Vendredi de 8h-12h30 et de 13h30-18h.</li>
    </ul>
    </p>
</header>
<main>
    <section>
        <h2>Service client:</h2>
        <ul>
            <li>Numéro de Téléphone: 0470804251</li>
            <li>E-mail:<a href="mailto:Barbapapa@gmail.com">Barbapapa@gmail.com</a></li>
            <li>Fax:+32 2 808 56 78</li>
        </ul>
    </section>

    <section>
        <form class="styled-form">
            <div class="form-group">
                <label for="nom">Nom :</label>
                <input type="text" id="nom" name="nom_utilisateur">
            </div>

            <div class="form-group">
                <label for="prénom">Prénom :</label>
                <input type="text" id="Prénom" name="prénom_utilisateur">
            </div>

            <div class="form-group">
                <label for="email">Email :</label>
                <input type="email" id="email" name="email_utilisateur">
            </div>

            <div>
                <label for="Problème rencontré">Problème rencontré:</label>
                <select name="Problème rencontré">
                    <option value="a">Je n'arrive pas à me connecter</option>
                    <option value="b">J'ai oublié mon mot de passe</option>
                    <option value="c">Je n'ai pas reçu mon colis</option>
                </select>
            </div>
            <br>

            <div class="form-group">
                <label for="message">Autres Problèmes? :</label>
                <textarea id="message" name="message_utilisateur"></textarea>
            </div>
            <button type="submit" class="submit-btn">Envoyer</button>
        </form>
    </section>
</main>
<?php
include 'includes/footer.php'; ?>

</body>

</html>