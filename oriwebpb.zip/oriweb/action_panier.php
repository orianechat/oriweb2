<?php
session_start(); // Obligatoire pour manipuler le panier [cite: 12]

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$action = isset($_GET['action']) ? $_GET['action'] : '';

if ($id > 0) {
    switch ($action) {
        case 'ajouter':
            // Si le produit est déjà là, on augmente la quantité, sinon on l'initialise à 1 
            if (isset($_SESSION['panier'][$id])) {
                $_SESSION['panier'][$id]++;
            } else {
                $_SESSION['panier'][$id] = 1;
            }
            break;

        case 'supprimer':
            unset($_SESSION['panier'][$id]); // Retire le produit 
            break;
    }
}

if ($action == 'vider') {
    unset($_SESSION['panier']); // Vide tout le panier 
}

// Redirection vers la page panier après l'action
header("Location: panier.php");
exit;
