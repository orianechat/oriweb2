<?php
session_start();
require_once 'includes/db.php';
include 'includes/header.php';
$total_general = 0;
?>

<main>
    <h1>Votre Panier</h1>

    <?php if (!empty($_SESSION['panier'])): ?>
        <table>
            <tr>
                <th>Produit</th>
                <th>Prix Unitaire</th>
                <th>Quantité</th>
                <th>Sous-total</th>
                <th>Action</th>
            </tr>

            <?php
            foreach ($_SESSION['panier'] as $id => $quantite):
                $sql = "SELECT * FROM produits WHERE id = $id";
                $res = $conn->query($sql);
                $p = $res->fetch_assoc();
                $sous_total = $p['prix'] * $quantite;
                $total_general += $sous_total;
            ?>
                <tr>
                    <td><?= $p['nom'] ?></td>
                    <td><?= $p['prix'] ?> €</td>
                    <td><?= $quantite ?></td>
                    <td><?= number_format($sous_total, 2) ?> €</td>
                    <td><a href="action_panier.php?action=supprimer&id=<?= $id ?>">Supprimer</a></td>
                </tr>
            <?php endforeach; ?>

            <tr>
                <td colspan="3"><strong>TOTAL GÉNÉRAL</strong></td>
                <td colspan="2"><strong><?= number_format($total_general, 2) ?> €</strong></td>
            </tr>
        </table>

        <p><a href="action_panier.php?action=vider">Vider le panier</a></p>
    <?php else: ?>
        <p>Votre panier est vide.</p>
    <?php endif; ?>

    <p><a href="catalogue.php">Continuer mes achats</a></p>
</main>

<?php include 'footer.php'; ?>