<!DOCTYPE html>
<html lang="fr">

<?php
include 'includes/header.php'; ?>

<header>
    <h1>Qui sommes-nous ?</h1>
    <p>Electrogear est une société d'électroménager de qualité au meilleur prix. <br>
        Crée en 2020 à liège en Belgique. Nous avons actuellement 15 magasins un peu partout dans le pays.
    </p>
</header>
<main>
    <h2>Nos Fondateurs:</h2>
    <img src="./images/fondateur.jpg" alt="Photo de nos Fondateurs">
</main>
<?php
include 'includes/footer.php'; ?>
</body>

</html>