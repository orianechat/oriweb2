 <!DOCTYPE html>
 <html lang="fr">

 <?php
    include 'includes/header.php'; ?>
 <main>
     <form action="/traitement-connexion" method="POST" class="styled-form">
         <h2>Connexion :</h2>

         <div class="form-group">
             <label for="mot_de_passe">Mot de passe :</label>

             <input type="email"
                 id="adresse_mail"
                 name="email_utilisateur"
                 required
                 placeholder="adresse mail ">
             <br>
             <input type="password"
                 id="mot_de_passe"
                 name="password"
                 required
                 placeholder="Entrez votre mot de passe">
         </div>

         <br>

         <button type="submit" class="submit-btn">Se connecter</button>
     </form>
 </main>
 <?php
    include 'includes/footer.php'; ?>
 </body>

 </html>