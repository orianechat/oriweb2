<?php
require_once 'includes/db.php';
include 'includes/header.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$sql = "SELECT * FROM produits WHERE id = $id";
$result = $conn->query($sql);
$produit = $result->fetch_assoc();

if (!$produit) {
    echo "Produit introuvable.";
    exit;
}
?>

<main>
    <h1><?= $produit['nom'] ?></h1>
    <img src="<?= $produit['image'] ?>" alt="<?= $produit['nom'] ?>" width="300">
    <p><?= $produit['description'] ?></p>
    <p><strong>Prix : <?= $produit['prix'] ?> €</strong></p>

    <a href="action_panier.php?action=ajouter&id=<?= $produit['id'] ?>" class="btn">Ajouter au panier</a>
</main>

<?php include 'footer.php'; ?>