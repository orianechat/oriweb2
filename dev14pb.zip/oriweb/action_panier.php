<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

if (isset($_POST['ajouter_panier'])) {
    $id = (int)$_POST['id'];

    $sql = "SELECT * FROM produits WHERE id = $id";
    $result = $conn->query($sql);
    $produitChoisi = $result->fetch_assoc();

    if ($produitChoisi) {
        if (isset($_SESSION['panier'][$id])) {
            $_SESSION['panier'][$id]['quantite']++;
        } else {

            $_SESSION['panier'][$id] = [
                'nom' => $produitChoisi['nom'],
                'prix' => $produitChoisi['prix'],
                'image' => $produitChoisi['image'],
                'quantite' => 1
            ];
        }
    }

    header("Location: Panier.php");
    exit();
}

if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    switch ($_GET['action']) {
        case 'ajouter':
            if (isset($_SESSION['panier'][$id])) {
                $_SESSION['panier'][$id]['quantite']++;
            }
            break;

        case 'diminuer':
            if (isset($_SESSION['panier'][$id])) {
                $_SESSION['panier'][$id]['quantite']--;
                if ($_SESSION['panier'][$id]['quantite'] <= 0) {
                    unset($_SESSION['panier'][$id]);
                }
            }
            break;

        case 'supprimer':
            if (isset($_SESSION['panier'][$id])) {
                unset($_SESSION['panier'][$id]);
            }
            break;
    }

    header("Location: Panier.php");
    exit();
}
