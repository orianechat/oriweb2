<?php
session_start();
include 'includes/header.php';
include 'includes/db.php';


$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$sql = "SELECT * FROM produits WHERE id = $id";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $p = $result->fetch_assoc();
} else {
    echo "<main style='padding: 50px; text-align: center;'>
            <h1 style='color: #e74c3c;'>Produit introuvable</h1>
            <p>Le produit que vous recherchez n'existe pas ou a été supprimé.</p>
            <a href='Catalogue.php' class='button-like' style='text-decoration:none; background:#333; color:#fff; padding:10px 20px; border-radius:5px;'>Retour au catalogue</a>
          </main>";
    include 'includes/footer.php';
    exit();
}
?>

<main style="padding: 40px; max-width: 900px; margin: 0 auto; font-family: Arial, sans-serif;">
    <div style="display: flex; gap: 40px; align-items: flex-start; flex-wrap: wrap;">

        <div style="flex: 1; min-width: 300px;">
            <img src="<?php echo htmlspecialchars($p['image']); ?>"
                alt="<?php echo htmlspecialchars($p['nom']); ?>"
                style="width: 100%; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
        </div>

        <div style="flex: 1; min-width: 300px;">
            <h1 style="margin-top: 0; color: #333;"><?php echo htmlspecialchars($p['nom']); ?></h1>

            <p style="font-size: 1.8em; color: #2ecc71; font-weight: bold; margin: 15px 0;">
                <?php echo number_format($p['prix'], 2, ',', ' '); ?> €
            </p>

            <div style="border-top: 1px solid #eee; border-bottom: 1px solid #eee; padding: 20px 0; margin-bottom: 25px;">
                <h3 style="margin-top: 0;">Description :</h3>
                <p style="line-height: 1.6; color: #555;">
                    <?php echo nl2br(htmlspecialchars($p['description'])); ?>
                </p>
            </div>

            <form action="action_panier.php" method="POST">
                <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
                <input type="hidden" name="ajouter_panier" value="1">

                <button type="submit" class="button-like" style="background-color: #27ae60; color: white; padding: 15px 30px; border: none; border-radius: 5px; cursor: pointer; font-size: 1.1em; width: 100%;">
                    Ajouter au panier
                </button>
            </form>

            <p style="margin-top: 30px; text-align: center;">
                <a href="Catalogue.php" style="color: #3333; text-decoration: none;">← Retourner aux achats</a>
            </p>
        </div>
    </div>
</main>

<?php
include 'includes/footer.php';
?>