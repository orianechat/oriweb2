<?php
session_start();
include 'includes/header.php';
include 'includes/db.php';

$prixMin = isset($_GET['prix_min']) && $_GET['prix_min'] !== '' ? (float)$_GET['prix_min'] : 0;
$prixMax = isset($_GET['prix_max']) && $_GET['prix_max'] !== '' ? (float)$_GET['prix_max'] : 5000;
$recherche = isset($_GET['search']) ? $_GET['search'] : '';

?>

<main>
    <section class="filter-section" style="padding: 20px; background: #f4f4f4; margin-bottom: 20px;">
        <form method="GET" action="Catalogue.php">
            <input type="text" name="search" placeholder="Rechercher un produit..." value="<?php echo htmlspecialchars($recherche); ?>">

            <label>Prix min :</label>
            <input type="number" name="prix_min" value="<?php echo $prixMin; ?>" style="width: 80px;">

            <label>Prix max :</label>
            <input type="number" name="prix_max" value="<?php echo $prixMax; ?>" style="width: 80px;">

            <button type="submit" class="button-like">Filtrer</button>
            <a href="Catalogue.php" style="margin-left: 10px; color: #3333;">Effacer</a>
        </form>
    </section>

    <div class="boites-container" style="display: flex; flex-wrap: wrap; gap: 20px; justify-content: center;">
        <?php

        $searchEscaped = $conn->real_escape_string($recherche);

        $sql = "SELECT * FROM produits 
                WHERE prix BETWEEN $prixMin AND $prixMax 
                AND nom LIKE '%$searchEscaped%'";

        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {

            while ($p = $result->fetch_assoc()) {
        ?>
                <div class="produit-card" style="border: 1px solid #ddd; padding: 15px; border-radius: 8px; width: 250px; text-align: center;">
                    <h3><?php echo htmlspecialchars($p['nom']); ?></h3>

                    <div style="height: 150px; display: flex; align-items: center; justify-content: center;">
                        <img src="<?php echo htmlspecialchars($p['image']); ?>" alt="<?php echo htmlspecialchars($p['nom']); ?>" style="max-width: 100%; max-height: 100%;">
                    </div>

                    <p style="font-weight: bold; font-size: 1.2em; color: #2ecc71;">
                        <?php echo number_format($p['prix'], 2, ',', ' '); ?> €
                    </p>

                    <a href="Produit.php?id=<?php echo $p['id']; ?>" class="button-like" style="display: block; margin-top: 10px; text-decoration: none; background: #333; color: #fff; padding: 8px; border-radius: 4px;">
                        Voir le produit
                    </a>
                </div>
        <?php
            }
        } else {
            echo "<p style='text-align: center; width: 100%;'>Aucun produit ne correspond à votre recherche.</p>";
        }
        ?>
    </div>
</main>

<?php
include 'includes/footer.php';
?>