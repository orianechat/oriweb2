<?php
session_start();
include 'includes/header.php';
?>
<!DOCTYPE html>
<html lang="fr">
<main style="padding: 20px; font-family: sans-serif;">
    <h1>Votre Panier</h1>

    <?php if (empty($_SESSION['panier'])): ?>
        <p>Votre panier est vide.</p>
        <a href="Catalogue.php" class="button-like">Retourner au catalogue</a>
    <?php else: ?>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
            <thead>
                <tr style="border-bottom: 2px solid #ccc;">
                    <th>Produit</th>
                    <th>Prix Unitaire</th>
                    <th>Quantité</th>
                    <th>Sous-total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $totalGeneral = 0;
                foreach ($_SESSION['panier'] as $id => $details):
                    $sousTotal = $details['prix'] * $details['quantite'];
                    $totalGeneral += $sousTotal;
                    $stockMax = isset($details['stock_max']) ? $details['stock_max'] : 0;
                ?>
                    <tr style="border-bottom: 1px solid #eee; text-align: center;">
                        <td style="padding: 10px;">
                            <img src="<?php echo $details['image']; ?>" width="50" style="vertical-align: middle; margin-right: 10px;">
                            <?php echo htmlspecialchars($details['nom']); ?>
                        </td>
                        <td><?php echo number_format($details['prix'], 2, ',', ' '); ?>€</td>

                        <td>
                            <a href="action_panier.php?action=diminuer&id=<?php echo $id; ?>"
                                style="text-decoration: none; padding: 5px 10px; background: #eee; color: black;">-</a>

                            <span style="margin: 0 10px; font-weight: bold;"><?php echo $details['quantite']; ?></span>

                            <?php if ($details['quantite'] < $stockMax): ?>
                                <a href="action_panier.php?action=ajouter&id=<?php echo $id; ?>"
                                    style="text-decoration: none; padding: 5px 10px; background: #eee; color: black;">+</a>
                            <?php else: ?>
                                <span style="padding: 5px 10px; background: #f8f8f8; color: #ccc; cursor: not-allowed;" title="Stock max atteint">+</span>
                            <?php endif; ?>
                        </td>

                        <td><?php echo number_format($sousTotal, 2, ',', ' '); ?>€</td>
                        <td>
                            <a href="action_panier.php?action=supprimer&id=<?php echo $id; ?>" style="color: red; text-decoration: none;">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div style="text-align: right; font-size: 1.5em;">
            <strong>Total Général : <?php echo number_format($totalGeneral, 2, ',', ' '); ?>€</strong>
        </div>

        <div style="margin-top: 20px; display: flex; justify-content: space-between;">
            <a href="Catalogue.php" class="button-like">Continuer mes achats</a>

            <a href="vider_panier.php" class="button-like" style="background-color:#333333; color: white; text-decoration: none;">Vider le panier</a>

            <button class="button-like" style="background-color: black; color: white; border: none;">Procéder au paiement</button>
        </div>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>
</body>

</html>